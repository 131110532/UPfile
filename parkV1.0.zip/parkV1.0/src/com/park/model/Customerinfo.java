package com.park.model;

import java.util.HashSet;
import java.util.Set;

/**
 * Customerinfo entity. @author MyEclipse Persistence Tools
 */

public class Customerinfo implements java.io.Serializable {

	// Fields

	private String idcard;
	private Login login;
	private String name;
	private String sex;
	private String phoneNumber;
	private Set parkspaces = new HashSet(0);

	// Constructors

	/** default constructor */
	public Customerinfo() {
	}

	/** minimal constructor */
	public Customerinfo(String idcard, Login login, String name, String sex,
			String phoneNumber) {
		this.idcard = idcard;
		this.login = login;
		this.name = name;
		this.sex = sex;
		this.phoneNumber = phoneNumber;
	}

	/** full constructor */
	public Customerinfo(String idcard, Login login, String name, String sex,
			String phoneNumber, Set parkspaces) {
		this.idcard = idcard;
		this.login = login;
		this.name = name;
		this.sex = sex;
		this.phoneNumber = phoneNumber;
		this.parkspaces = parkspaces;
	}

	// Property accessors

	public String getIdcard() {
		return this.idcard;
	}

	public void setIdcard(String idcard) {
		this.idcard = idcard;
	}

	public Login getLogin() {
		return this.login;
	}

	public void setLogin(Login login) {
		this.login = login;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSex() {
		return this.sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getPhoneNumber() {
		return this.phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public Set getParkspaces() {
		return this.parkspaces;
	}

	public void setParkspaces(Set parkspaces) {
		this.parkspaces = parkspaces;
	}

}