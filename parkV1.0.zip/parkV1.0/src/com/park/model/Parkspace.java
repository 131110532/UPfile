package com.park.model;

/**
 * Parkspace entity. @author MyEclipse Persistence Tools
 */

public class Parkspace implements java.io.Serializable {

	// Fields

	private String parkSpaceId;
	private Customerinfo customerinfo;
	private String location;
	private String ifIdle;

	// Constructors

	/** default constructor */
	public Parkspace() {
	}

	/** full constructor */
	public Parkspace(String parkSpaceId, Customerinfo customerinfo,
			String location, String ifIdle) {
		this.parkSpaceId = parkSpaceId;
		this.customerinfo = customerinfo;
		this.location = location;
		this.ifIdle = ifIdle;
	}

	// Property accessors

	public String getParkSpaceId() {
		return this.parkSpaceId;
	}

	public void setParkSpaceId(String parkSpaceId) {
		this.parkSpaceId = parkSpaceId;
	}

	public Customerinfo getCustomerinfo() {
		return this.customerinfo;
	}

	public void setCustomerinfo(Customerinfo customerinfo) {
		this.customerinfo = customerinfo;
	}

	public String getLocation() {
		return this.location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getIfIdle() {
		return this.ifIdle;
	}

	public void setIfIdle(String ifIdle) {
		this.ifIdle = ifIdle;
	}

}