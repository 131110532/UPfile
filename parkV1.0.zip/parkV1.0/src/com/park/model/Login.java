package com.park.model;

import java.util.HashSet;
import java.util.Set;

/**
 * Login entity. @author MyEclipse Persistence Tools
 */

public class Login implements java.io.Serializable {

	// Fields

	private String userName;
	private String passWord;
	private Integer role;
	private Set customerinfos = new HashSet(0);

	// Constructors

	/** default constructor */
	public Login() {
	}

	/** minimal constructor */
	public Login(String userName, String passWord, Integer role) {
		this.userName = userName;
		this.passWord = passWord;
		this.role = role;
	}

	/** full constructor */
	public Login(String userName, String passWord, Integer role,
			Set customerinfos) {
		this.userName = userName;
		this.passWord = passWord;
		this.role = role;
		this.customerinfos = customerinfos;
	}

	// Property accessors

	public String getUserName() {
		return this.userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassWord() {
		return this.passWord;
	}

	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}

	public Integer getRole() {
		return this.role;
	}

	public void setRole(Integer role) {
		this.role = role;
	}

	public Set getCustomerinfos() {
		return this.customerinfos;
	}

	public void setCustomerinfos(Set customerinfos) {
		this.customerinfos = customerinfos;
	}

}