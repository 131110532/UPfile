package com.park.controy;


import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import org.hibernate.Session;
import com.park.dao.LoginDAO;
import com.park.dao.ParkspaceDAO;
import com.park.factory.HibernateSessionFactory;
import com.park.model.Login;
import com.park.model.Parkspace;


public class mainFormControy {
	
	public static mainFormControy control = null; 
	public static mainFormControy getmainFormControl(){
		if(null==control){
			control = new mainFormControy();
		}
		return control;
	}
	
	private static ParkspaceDAO ParkspaceDAO = null;
	private Session session = null;
	
	private mainFormControy(){
		ParkspaceDAO = new ParkspaceDAO();
		session = HibernateSessionFactory.getSession();
		
	}
	
	public Parkspace getParkByID(String ID){
		// System.out.println(ID);
		  return (Parkspace)ParkspaceDAO.findByProperty("parkSpaceId",ID).get(0);

	}

	public Boolean update(Parkspace temp)
	{
		try
		{
			ParkspaceDAO.merge(temp);
			session.beginTransaction().commit();
			session.flush();
			return true;
		}
		catch(Exception e)
		{
			return false;
		}
	}
	
	

	
	
	public static Boolean ifIdle(String Tlocation){
		int mark=0;
		ParkspaceDAO dao =new ParkspaceDAO();
		List l = dao.findByName_blur(Tlocation);
		for (int i = 0; i < l.size(); i++) {
			if(((Parkspace) l.get(i)).getIfIdle().equals("0")){
			    mark=1;
			    break;
			}
		}	
		if(mark==1)
		    return true;
		else
			return false;
	}
	
	public static void displayInfo(String Tlocation,JTable table){
		ParkspaceDAO dao1 =new ParkspaceDAO();
		DefaultTableModel tableModel = (DefaultTableModel)table.getModel();
	    tableModel.setRowCount(0);
	    Parkspace park1=null;
		List l = dao1.findByName_blur(Tlocation);
		String [] record = new  String[3];
		for (int i = 0; i < l.size(); i++) {
			park1=(Parkspace)l.get(i);
			if(((Parkspace) l.get(i)).getIfIdle().equals("0")){
				//park1.setIfIdle("1");
				record[0]=park1.getParkSpaceId();
		    	record[1]=park1.getLocation();
		    	record[2]=park1.getIfIdle();
		    	if(park1.getIfIdle().equals("0"))
		    	{
		    		record[2]="����";
		    	}
		    	tableModel.addRow(record);
			}
		}
	}
    
	
	
}
