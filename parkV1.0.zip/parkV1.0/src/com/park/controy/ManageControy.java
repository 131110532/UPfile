package com.park.controy;

import java.util.List;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import org.hibernate.Session;

import com.park.dao.ParkspaceDAO;
import com.park.factory.HibernateSessionFactory;
import com.park.model.Parkspace;

public class ManageControy {
	public static ManageControy control = null; 
	public static ManageControy getManageControyControl(){
		if(null==control){
			control = new ManageControy();
		}
		return control;
	}
	
	private static ParkspaceDAO ParkspaceDAO = null;
	private Session session = null;
	
	private ManageControy(){
		ParkspaceDAO = new ParkspaceDAO();
		session = HibernateSessionFactory.getSession();
	}
	
	
	public static void displayInfo(JTable table){
		ParkspaceDAO dao1 =new ParkspaceDAO();
		DefaultTableModel tableModel = (DefaultTableModel)table.getModel();
	    tableModel.setRowCount(0);
	    Parkspace park1=null;
		List l = dao1.findAll();
		String [] record = new  String[3];
		for (int i = 0; i < l.size(); i++) {
			park1=(Parkspace)l.get(i);
			record[0]=park1.getParkSpaceId();
		    record[1]=park1.getLocation();
		    record[2]=park1.getIfIdle();
		    if(park1.getIfIdle().equals("0")){
		    	record[2]="����";
		    }
		    else
		    	record[2]="ռ��";
		    tableModel.addRow(record);
		}
	}

}
