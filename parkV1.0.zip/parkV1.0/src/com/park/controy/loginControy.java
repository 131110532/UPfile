package com.park.controy;

import java.util.List;

import org.hibernate.Session;

import com.park.dao.LoginDAO;
import com.park.factory.HibernateSessionFactory;
import com.park.model.Login;
import com.park.model.Parkspace;


public class loginControy {
	
    public static loginControy control = null; 
	public static loginControy getLoginControl(){
		if(null==control){
			control = new loginControy();
		}
		return control;
	}
	
	private LoginDAO LoginDAO = null;
	private Session session = null;
	
	private loginControy(){
		LoginDAO = new LoginDAO();
		session = HibernateSessionFactory.getSession();
	}
	
	public Login getLoginByName(String username){
		
		  return (Login)LoginDAO.findByProperty("userName",username).get(0);

	}
	
	public List getLoginALL(){
		
		  return LoginDAO.findAll();

	}
	
	public static Boolean isUser(String username,String password)
	{
		List list1=loginControy.getLoginControl().getLoginALL();
		int a=0;
		for(int i = 0;i < list1.size();i++)
		{
			Login login = (Login)list1.get(i);
			String [] tep = new String[2];
			tep[0]=login.getUserName().toString();
			tep[1]=login.getPassWord().toString();
			if( tep[0].equals(username)&&tep[1].equals(password)){
				a=1;
				break;
			}
		}

		/*Login login1=null;
		System.out.println(login1.getPassWord());
		login1 = loginControy.getLoginControl().getLoginByName(username);*/
		
		if(a==1)
			return true;
		else
			return false;
	}
	
	
}