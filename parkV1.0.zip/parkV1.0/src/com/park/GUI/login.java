package com.park.GUI;


import com.park.controy.*;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.awt.*;
import java.awt.Window.Type;


public class login extends JFrame{
	private JFrame mainForm = null;
	private JFrame ManageGUI = null;
	JFrame frame = new JFrame();
	private JTextField textField_1;
	private JPasswordField passwordField_1;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					login frame = new login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public login() {
		
		setType(Type.POPUP);
		setForeground(Color.WHITE);
		setTitle("login");
		    setResizable(false);
		    setBounds(600, 300, 563, 369);
		    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		    getContentPane().setLayout(null);
		    
		    JLabel label = new JLabel("\u5FEB\u901F\u627E\u8F66\u4F4D");
		    label.setFont(new Font("���Ŀ���", Font.PLAIN, 43));
		    label.setForeground(Color.BLACK);
		    label.setBounds(168, 41, 270, 64);
		    getContentPane().add(label);
		    
		    JLabel label_1 = new JLabel("\u5E10\u53F7\uFF1A");
		    label_1.setFont(new Font("����", Font.BOLD, 25));
		    label_1.setBounds(117, 128, 96, 24);
		    getContentPane().add(label_1);
		    
		    JLabel label_2 = new JLabel("\u5BC6\u7801\uFF1A");
		    label_2.setFont(new Font("����", Font.BOLD, 25));
		    label_2.setBounds(117, 180, 96, 24);
		    getContentPane().add(label_2);
		    
		    textField_1 = new JTextField();
		    textField_1.setBounds(227, 128, 86, 24);
		    getContentPane().add(textField_1);
		    textField_1.setColumns(10);
		    
		    passwordField_1 = new JPasswordField();
		    passwordField_1.setBounds(227, 180, 86, 24);
		    getContentPane().add(passwordField_1);
		    
		    JButton button = new JButton("\u767B\u5F55");
		    button.addActionListener(new ActionListener() {
		    	public void actionPerformed(ActionEvent e) {
		    		if(loginControy.isUser(textField_1.getText(), String.valueOf(passwordField_1.getPassword())))
					{
						frame.setVisible(false);
						dispose();
						if(textField_1.getText().equals("manage")){
							ManageGUI=new ManageGUI();
							ManageGUI.setVisible(true);
						}
						else{
					    mainForm = new mainForm();
						mainForm.setVisible(true);
						}
					}
					else 
					{      
						JOptionPane.showConfirmDialog(null, "�û������������","��ʾ:", JOptionPane.CLOSED_OPTION);
					}
		    	}
		    });
		    button.setBounds(213, 256, 113, 27);
		    getContentPane().add(button);
 
			
		}
}
