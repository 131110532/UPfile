package com.park.GUI;
import java.awt.BorderLayout;
import java.awt.CardLayout;

import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JButton;
import javax.swing.ImageIcon;

import com.park.controy.*;
import com.park.dao.ParkspaceDAO;
import com.park.model.Parkspace;

import java.awt.Font;

import javax.swing.JScrollBar;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import java.awt.ScrollPane;

import javax.swing.JScrollPane;

public class mainForm extends javax.swing.JFrame{
	String Tlocation;
	private JTable table;
	
	
    public mainForm(){ 	
    	setTitle("mainForm");
    	setResizable(false);
		setBounds(600, 300, 563, 369);
		getContentPane().setLayout(null);
		
		JLabel label = new JLabel("\u6240\u5728\u5927\u533A");
		label.setFont(new Font("����", Font.BOLD, 30));
		label.setBounds(116, 23, 145, 50);
		getContentPane().add(label);
		
		
		
		String labels[] ={" ","������","����","�Ǳ�","ʮ����"};
		JComboBox comboBox = new JComboBox(labels);
		comboBox.setEditable(true);
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Tlocation=((JComboBox)e.getSource()).getSelectedItem().toString();
				System.out.println(Tlocation);
			}
		});
		comboBox.setBounds(295, 23, 145, 43);
		getContentPane().add(comboBox);
		
		
		JButton button = new JButton("\u4E00\u952E\u67E5\u627E");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(mainFormControy.ifIdle(Tlocation))
				{
					mainFormControy.displayInfo(Tlocation,table);
				}
				else 
				{    
					mainFormControy.displayInfo(Tlocation,table);
					JOptionPane.showConfirmDialog(null, "������λ����","��Ǹ:", JOptionPane.CLOSED_OPTION);
				}
			}
		});
		button.setIcon(new ImageIcon("D:\\myeclipseWORK\\park1\\image\\anniu.png"));
		button.setBounds(194, 79, 156, 67);
		getContentPane().add(button);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(98, 159, 342, 87);
		getContentPane().add(scrollPane_1);
		
		table = new JTable();
		scrollPane_1.setViewportView(table);
		
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
			},
			new String[] {
				"\u505C\u8F66\u4F4DID", "\u5730\u533A", "\u8F66\u4F4D\u72B6\u6001"
			}
		));
		
		JButton btnNewButton = new JButton("New button");     //Ԥ����ť����
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel tableModel = (DefaultTableModel)table.getModel();
				int rows = table.getSelectedRowCount();
				if(rows==0)
				{
					JOptionPane.showConfirmDialog(null, "��ѡ������ҪԤ���ĳ�λ","��ʾ:", JOptionPane.CLOSED_OPTION);
					return;
				}
                int row  = table.getSelectedRow();
                Parkspace park1 = mainFormControy.getmainFormControl().getParkByID((String)tableModel.getValueAt(row,0))  ; 
                park1.setIfIdle("1");
                System.out.println(park1.getIfIdle());
                try {
                	mainFormControy.getmainFormControl().update(park1);
                	JOptionPane.showConfirmDialog(null, "���Ѿ��ɹ�Ԥ���ó�λ","��ʾ:", JOptionPane.CLOSED_OPTION);
                	mainFormControy.displayInfo(Tlocation,table);
				} catch (Exception ex) {
					ex.printStackTrace();
				}
				
			}
		});
		btnNewButton.setIcon(new ImageIcon("D:\\myeclipseWORK\\park1\\image\\QQ\u56FE\u724720150526133008.png"));
		btnNewButton.setBounds(194, 259, 156, 62);
		getContentPane().add(btnNewButton);
		
    }
}
