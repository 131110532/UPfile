package com.park.GUI;

import com.park.controy.*;
import com.park.model.Parkspace;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import java.awt.Window.Type;


public class ManageGUI extends JFrame{
	JFrame frame = new JFrame();
	private JTable table;
	private JFrame AddParkspaceGUI = null;
	
	
	
	public ManageGUI() {
		setTitle("����");
    	setResizable(false);
		setBounds(600, 300, 563, 369);
		getContentPane().setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(34, 55, 492, 126);
		getContentPane().add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
			},
			new String[] {
				"\u505C\u8F66\u4F4DID", "\u5730\u533A", "\u8F66\u4F4D\u72B6\u6001"
			}
		));
		
		ManageControy.displayInfo(table);
		
		JButton button = new JButton("\u589E\u52A0\u8F66\u4F4D");    //���ӳ�λ
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Parkspace park1=null;
				frame.setVisible(false);
                AddParkspaceGUI=new JFrame();
                AddParkspaceGUI.setVisible(true);
			}
		});
		button.setBounds(34, 225, 113, 27);
		getContentPane().add(button);
		
		JButton button_1 = new JButton("\u5220\u9664\u8F66\u4F4D");
		button_1.setBounds(161, 225, 113, 27);
		getContentPane().add(button_1);
		
		JButton button_2 = new JButton("\u4FEE\u6539\u4FE1\u606F");
		button_2.setBounds(288, 225, 113, 27);
		getContentPane().add(button_2);
		
		JButton button_3 = new JButton("\u67E5\u627E\u8F66\u4F4D");
		button_3.setBounds(415, 225, 113, 27);
		getContentPane().add(button_3);
	}
}
