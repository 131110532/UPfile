package com.park.GUI;

import com.park.controy.*;
import com.park.model.Parkspace;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import java.awt.Window.Type;

public class AddParkspaceGUI extends JFrame{
	private JTextField textField;
	private JTextField textField_1;
	
	
	public AddParkspaceGUI() {
		setType(Type.POPUP);
		setForeground(Color.WHITE);
		setTitle("���ӳ�λ");
		setResizable(false);
		setBounds(600, 300, 563, 369);
		getContentPane().setLayout(null);
		
		JLabel label = new JLabel("\u8F66\u4F4D\u7F16\u53F7\uFF1A");
		label.setBounds(116, 69, 101, 32);
		getContentPane().add(label);
		
		textField = new JTextField();
		textField.setBounds(217, 69, 92, 28);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel label_1 = new JLabel("\u5177\u4F53\u65B9\u4F4D\uFF1A");
		label_1.setBounds(116, 132, 101, 32);
		getContentPane().add(label_1);
		
		textField_1 = new JTextField();
		textField_1.setBounds(217, 136, 92, 28);
		getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lbln = new JLabel("\u63D0\u793A\uFF1A\u5C11\u4E8E10\u4F4D");
		lbln.setBounds(337, 35, 191, 100);
		getContentPane().add(lbln);
		
		JButton button = new JButton("\u786E\u8BA4\u6DFB\u52A0");
		button.setBounds(136, 235, 113, 27);
		getContentPane().add(button);
		
		JButton button_1 = new JButton("\u8FD4\u56DE");
		button_1.setBounds(337, 235, 113, 27);
		getContentPane().add(button_1);
	}
}
